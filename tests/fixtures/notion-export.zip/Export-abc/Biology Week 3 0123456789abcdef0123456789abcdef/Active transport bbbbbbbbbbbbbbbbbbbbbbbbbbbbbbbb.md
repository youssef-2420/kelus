Active transport moves substances across a membrane against their concentration gradient, from low to high concentration, and it requires energy in the form of ATP. The sodium-potassium pump is the classic example.

## Why cells need it

Cells keep ion concentrations different from their surroundings, which is essential for nerve signals.
